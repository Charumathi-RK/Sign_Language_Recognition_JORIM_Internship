from roboflow import Roboflow

rf = Roboflow(api_key='Osoic7hXLXg7oab7m7AY')

#WORKSPACE

workspace = rf.workspace()
project =workspace.project('sign-language-v8piv')
version =project.version(1)

model=version.model

def predict_image(image_path):
    prediction = model.predict(image_path)
    predictions = prediction.json()
    if 'predictions' in predictions and len(predictions['predictions']) > 0:
        for p in predictions['predictions']:
            class_label = p['class']
            confidence = p['confidence']
            print(f"Class: {class_label}, Confidence: {confidence*100:.2f}%")
    else:
        print("No predictions found!")
    print()
    prediction.plot()

img = r"test_images\book.jpg"
predict_image(img)